import React from 'react';
import { RecipieDetail } from '@/app/recipie-list/[details]/page';
interface RecipieDetailListProps {
  getDetailData: RecipieDetail;
}

const RecipieDetailList: React.FC<RecipieDetailListProps> = ({getDetailData}) => {
  //console.log(getDetailData,"getDetailData")
  return (
    <div>page</div>
  )
}

export default RecipieDetailList;

